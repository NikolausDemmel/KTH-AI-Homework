/*
 * defines.h
 *
 *  Created on: 06.10.2011
 *      Author: demmeln
 */

#ifndef DEFINES_H_
#define DEFINES_H_

#define NDEBUG
#define BOOST_UBLAS_NDEBUG


#endif /* DEFINES_H_ */
