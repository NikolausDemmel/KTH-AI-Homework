import random
import time
from constants import *
from caction import CAction

class CPlayer:
  #shoot!

  #This is the function where you should do all your work.

  #you will receive a variable pState, which contains information about all ducks,
  #both dead and alive. Each duck contains all past actions.

  #The state also contains the scores for all players and the number of
  #time steps elapsed since the last time this function was called.

  #Check their documentation for more information.
  # pState the state object
  # pDue time before which we must have returned
  #You must return the action to make, or None if you prefer to pass
  def shoot(self,pState,pDue):
    # Here you should write your clever algorithms to get the best action.
    # This skeleton never shoots.
    
    return None
    
    # This line would predict that bird 0 is totally stopped and shoot at it
    #return CAction(0,ACTION_STOP,ACTION_STOP,BIRD_STOPPED)


  #guess the species!

  #This function will be called at the end of the game, to give you
  #a chance to identify the species of the surviving ducks for extra
  #points.

  #For each alive duck in the vector, you must call the SetSpecies function,
  #passing one of the ESpecies constants as a parameter
  # pDucks a list with all ducks. You must identify only the ones that are alive
  # pDue time before which we must have returned
  def guess(self,pDucks,pDue):
    # Here you should write your clever algorithms to guess the species of each alive bird.
    # This skeleton guesses that all of them are white... they were the most likely after all!
    for d in pDucks:
      d.mSpecies=SPECIES_WHITE

  #This function will be called whenever you hit a duck.
  # pDuck the duck index
  # pSpecies the species of the duck (it will also be set for this duck in pState from now on)    
  def hit(self,pDuck,pSpecies):
    print('HIT DUCK!!!')
