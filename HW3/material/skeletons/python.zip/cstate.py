from constants import *

#represents the game state

# mDucks is a list of all the ducks
# mScores is a list of all the scores
# mWhoIAm is your index in the list of scores
# mNumNewTurns is the number of time steps elapsed since your last turn (will be 1 in single player)
class CState:
  def __init__(self):
    self.mDucks=[]
    self.mScores=[]
    self.mWhoIAm=0
    self.mNumNewTurns=0
