from constants import *

#represents an action of a bird, and its movement direction

#this class is used both for representing a past action and for
#shooting at a bird
class CAction:
  #construct a bird action object
  
  #pBirdNumber the bird index
  #pHAction the horizontal action of the bird
  #pVAction the horizontal action of the bird
  #pMovement the movement of the bird 
  def __init__(self,pBirdNumber,pHAction,pVAction,pMovement):
    self.mBirdNumber=pBirdNumber
    self.mHAction=pHAction
    self.mVAction=pVAction
    self.mMovement=pMovement

  def is_dead(self):
    return self.mMovement==BIRD_DEAD

  def print_it(self):
    lStr=str(self.mBirdNumber)+' '

    if self.is_dead():
      lStr+="DEAD DUCK"
    else:
      if self.mHAction==ACTION_ACCELERATE:
        lStr+="ACCELERATE "
      elif self.mHAction==ACTION_KEEPSPEED:
        lStr+="KEEPSPEED "
      else:
        lStr+="STOP "
      if self.mVAction==ACTION_ACCELERATE:
        lStr+="ACCELERATE"
      elif self.mVAction==ACTION_KEEPSPEED:
        lStr+="KEEPSPEED"
      else:
        lStr+="STOP"
            
      if self.mMovement==BIRD_STOPPED:
        lStr+=" STOPPED"
      else:
        if self.mMovement&MOVE_UP:
          lStr+=" UP"
        if self.mMovement&MOVE_DOWN:
          lStr+=" DOWN"
        if self.mMovement&MOVE_WEST:
          lStr+=" WEST"
        if self.mMovement&MOVE_EAST:
          lStr+=" EAST"
    print(lStr)
