#!/usr/bin/python
from cplayer import CPlayer
from csocket import CSocket
from cstate import CState
from cduck import CDuck
from caction import CAction
import time

import sys

if len(sys.argv)<4:
  print('usage: '+sys.argv[0]+" host port STANDALONE\n");
  sys.exit(1)
  
lPlayer=CPlayer()
lSocket=CSocket(sys.argv[1],int(sys.argv[2]))
lState=CState()

lStandalone=(sys.argv[3]=="STANDALONE")

if not lStandalone:
  print('this version can only run in standalone mode')
  sys.exit(1)

lArgs=' '.join(sys.argv[3:])

lSocket.write_line("MODE "+sys.argv[3])

while True:
  lState.mNumNewTurns=0;

  #read ducks
  while True:
    lState.mNumNewTurns+=1;

    lTokens=lSocket.read_line(True).split()
    
    lBirdCount=int(lTokens[1])
    
    if not lState.mDucks:
      for i in range(lBirdCount):
        lState.mDucks.append(CDuck())
    elif lBirdCount!=len(lState.mDucks):
      raise RuntimeError("wrong response from server (1)")

    for i in range(lBirdCount):
      lHorz=int(lTokens[i*3+2])
      lVert=int(lTokens[i*3+3])
      lMovement=int(lTokens[i*3+4])
      
      lState.mDucks[i].mActions.append(CAction(i,lHorz,lVert,lMovement));
    
    if int(lTokens[0])<=0:
      break;

  #read state
  lTokens=lSocket.read_line(True).split()

  lTime=int(lTokens[0])/1000000.0
  
  lDuck=int(lTokens[1])
  
  if lDuck>=0:
    lSpecies=int(lTokens[2])
    lState.mDucks[lDuck].mSpecies=lSpecies
    lPlayer.hit(lDuck,lSpecies)

  lState.mWhoIAm=int(lTokens[4])
  lNumPlayers=int(lTokens[5])
  if not lState.mScores:
    for i in range(lNumPlayers):
      lState.mScores.append(0)
  elif lNumPlayers!=len(lState.mScores):
    raise RuntimeError("wrong response from server")

  for i in range(lNumPlayers):
    lState.mScores[i]=int(lTokens[i+6])
      
  if int(lTokens[3]):
    if len(lState.mDucks)>1:
      if lStandalone:
        lTime=time.time()+60.0
      lPlayer.guess(lState.mDucks,lTime)
      lGuesses=[str(d.mSpecies) for d in lState.mDucks]
      lSocket.write_line(' '.join(lGuesses))
    break
  else:
    if lStandalone:
      lTime=time.time()+1.0
    lAction=lPlayer.shoot(lState,lTime)
    if lAction==None:
      lSocket.write_line("-1 0 0 0")
    else:
      lSocket.write_line(str(lAction.mBirdNumber)+' '+str(lAction.mHAction)+' '+str(lAction.mVAction)+' '+str(lAction.mMovement))

print(lSocket.read_line(True))


