#these values represent species

SPECIES_UNKNOWN=-1		# the species is unknown
SPECIES_WHITE=0			# the duck belongs to the white (common) species
SPECIES_BLACK=1			# the duck belongs to the black (endangered) species
SPECIES_BLUE=2			# the duck belongs to the blue species
SPECIES_RED=3			# the duck belongs to the red species
SPECIES_GREEN=4			# the duck belongs to the green species
SPECIES_YELLOW=5		# the duck belongs to the yellow species

#each of the three actions a bird can make
ACTION_ACCELERATE=0
ACTION_KEEPSPEED=1
ACTION_STOP=2

#used to represent the current movement state of a duck
BIRD_STOPPED=0
MOVE_WEST=(1<<0)
MOVE_EAST=(1<<1)
MOVE_UP=(1<<2)
MOVE_DOWN=(1<<3)
BIRD_DEAD=(1<<4)
