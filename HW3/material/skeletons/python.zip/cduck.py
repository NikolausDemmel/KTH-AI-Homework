from constants import *

#represents a duck
class CDuck:
  #initializes the move from a type and the associated data

  #mActions is a list of all the past actions of the duck
  #mSpecies contains the species of the bird  
  def __init__(self):
    self.mActions=[]
    self.mSpecies=SPECIES_UNKNOWN
    
  def is_dead(self):
    return self.mActions[-1].is_dead()
