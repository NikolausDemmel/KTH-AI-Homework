//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by guiCheck.rc
//
#define IDC_START                       1000
#define IDC_END                         1001
#define IDC_DEPTH                       1001
#define IDC_PREV                        1002
#define IDC_TIME                        1002
#define IDC_NEXT                        1003
#define IDC_GO                          1004
#define IDC_TAKEBACK                    1005
#define IDC_DEPTH_TEXT                  1006
#define IDC_TIME_TEXT                   1007
#define ID_FILE_EXIT                    40001
#define ID_GAME_NEW                     40002
#define ID_GAME_FLIPBOARD               40003
#define ID_GAME_HASHING                 40004
#define ID_GAME_COMPUTERMOVE            40006
#define ID_OPTIONS_BEGINNER             40007
#define ID_GAME_COMPUTEROFF             40009
#define ID_GAME_CLEAR_HASH              40010
#define ID_FILE_SAVEGAME                40011
#define ID_FILE_LOADGAME                40012
#define ID_OPTIONS_2SECONDS             40013
#define ID_OPTIONS_10SECONDS            40015
#define ID_OPTIONS_5SECONDS             40017
#define ID_OPTIONS_30SECONDS            40018
#define ID_EDIT_SETUPBOARD              40019
#define ID_EDIT_PASTE_POS               40022
#define ID_EDIT_COPY_POS                40023
#define ID_OPTIONS_CUSTOMLEVEL          40024
#define ID_Menu                         40025
#define ID_OPTIONS_EXPERT               40026
#define ID_OPTIONS_NORMAL               40027
#define ID_EDIT_COPY_PDN                40028
#define ID_EDIT_PASTE_PDN               40029
#define ID_OPTIONS_COMPUTERBLACK        40030
#define ID_OPTIONS_COMPUTERWHITE        40031
#define ID_GAME_MOVENOW                 40032

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        121
#define _APS_NEXT_COMMAND_VALUE         40032
#define _APS_NEXT_CONTROL_VALUE         1002
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
