int coortonumber(struct coor c, int gametype);
void numbertocoors(int number,int *x,int *y, int gametype);
int coorstonumber(int x,int y, int gametype);
void coorstocoors(int *x, int *y, int invert, int mirror);

