void	loadsettings(struct CBoptions *options, char CBdirectory[256]);
void	savesettings(struct CBoptions *options);
