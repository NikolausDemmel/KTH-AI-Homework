//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by checkerboard.rc
//
#define IDC_BROWSE_WLD_DIR_BUTTON       4
#define IDC_MORE_OPTIONS_BUTTON         5
#define IDC_BROWSE_MTC_DIR_BUTTON       6
#define IDC_BOOKFILE_BROWSE_BUTTON      7
#define IDD_MORE_ENGINE_OPTIONS_DIALOG  103
#define IDC_MTC_DIR_EDIT                1000
#define IDC_CHECK_WLD_BUTTON            1001
#define IDC_CHECK_WLD_DIR_BUTTON        1001
#define IDC_CHECK1                      1002
#define IDC_WLD_ENAB_CHECK              1002
#define IDC_MAX_PIECES_COMBO            1003
#define IDC_WLD_DIR_EDIT                1004
#define IDC_CHECK_MTC_DIR_BUTTON        1005
#define IDC_CHECK2                      1006
#define IDC_MTC_ENAB_CHECK              1006
#define IDC_BOOKFILE_EDIT               1007
#define IDC_MAX_SEARCH_THREADS_COMBO    1008
#define IDC_CPUS_EDIT                   1009
#define IDC_DBDIR_GROUP_BOX             1010
#define ID_LANGAGE_FRANCAIS             40039
#define ID_SPRACHE_FRANCAIS             40040
#define ID_LANGUAGE_FRANCAIS            40041

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40042
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
