void boardtobitboard(int b[8][8], struct pos *position);
void boardtocrbitboard(int b[8][8], struct pos *position);
void bitboardtoboard8(struct pos *p, int b[8][8]);
