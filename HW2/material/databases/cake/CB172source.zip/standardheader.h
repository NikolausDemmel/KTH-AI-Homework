#pragma warning(disable : 4996)
#include <assert.h>

