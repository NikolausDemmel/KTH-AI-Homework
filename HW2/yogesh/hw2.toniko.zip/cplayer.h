#ifndef _CHECKERS_CPLAYER_H_
#define _CHECKERS_CPLAYER_H_

#include "constants.h"
#include "ctime.h"
#include "cmove.h"
#include "cboard.h"
#include <vector>
#include <list>

namespace chk
{

class CPlayer
{
public:

/*	class GameState {
	public:
//		std::stack<GameState> unvisitedStates;
		CBoard board;
		float min;
		float max;
		float val;
		bool turn;	
		bool visited;
		int depth;
		GameState *parentState;
		CMove afterMove;

		GameState(CBoard tBoard,bool myTurn,int level,GameState *pState, CMove aMove) {
			board = tBoard;
			turn = myTurn;
			min = -99;
			max = 99;
			val = myTurn?-99:99;
			visited = false;
			depth = level;
			parentState = pState;
			afterMove = aMove;
		}

		int evaluated() {
		int own = 0;
		int opn = 0;
		for(int i = 0; i<32; i++) {
			if(board.At(i)&CELL_OWN) own++;
			if(board.At(i)&CELL_OTHER) opn++;
			}
		return own-opn;
		}

		
	};*/

    CTime startTime;
    int    depthChecked;
    CTime  idleReturnTime;
    CBoard myNextBoard;
    CMove  myNextMove;
    std::list<CMove> killerMoves;

	void anotherKillerMove(const CMove &aMove);
	bool isitKiller(const CMove &aMove);
	void sortIfKiller(std::vector<CMove> lMoves);

    ///constructor
    
    ///Shouldn't do much. Any expensive initialization should be in 
    ///Initialize
    CPlayer();

    ///called when waiting for the other player to move
    
    ///\param pBoard the current state of the board
    ///\return false if we don't want this function to be called again
    ///until next move, true otherwise
    bool Idle(const CBoard &pBoard);
    
    ///perform initialization of the player
    
    ///\param pFirst true if we will move first, false otherwise
    ///\param pDue time before which we must have returned. To check,
    ///for example, to check if we have less than 100 ms to return, we can check if
    ///CTime::GetCurrent()+100000>pDue or pDue-CTime::GetCurrent()<100000.
    ///All times are in microseconds.
    void Initialize(bool pFirst,const CTime &pDue);

    ///perform a move

    ///\param pBoard the current state of the board
    ///\param pDue time before which we must have returned
    ///\return the move we make
    CMove Play(const CBoard &pBoard,const CTime &pDue);
    
    ///perform minmax algo
    
    ///\param pBoard
    ///\param alph
    ///\param beta
    ///\param depth
    float maxVal(const CBoard &pBoard,float alph,float beta,int depth );
    
    ///\param pBoard
    ///\param alph
    ///\param beta
    ///\param depth
    float minVal(const CBoard &pBoard,float alph,float beta,int depth );
    
    float maxValT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue )throw (int) ;
    float minValT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue )throw (int) ;

    float maxMoveT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue,CMove &opMove )throw (int) ;

    
    CMove findBestMove(const CBoard &pBoard,const CTime &pDue);
    
};

/*namespace chk*/ }

#endif
