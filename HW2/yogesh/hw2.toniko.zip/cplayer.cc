#include "cplayer.h"
#include <cstdlib>
#include <iostream>
//#include <stack>
#define CRITICAL 1

namespace chk
{

CPlayer::CPlayer()
{
}

	void CPlayer::anotherKillerMove(const CMove &aMove) {
		std::list<CMove>::iterator it = killerMoves.begin();
		killerMoves.insert(it,aMove);
	}

	bool CPlayer::isitKiller(const CMove &aMove) {
		std::list<CMove>::iterator it = killerMoves.begin();

		for(;it!=killerMoves.end();it++) {
			if(aMove==*it) return true;
		}
		return false;
	}

	void CPlayer::sortIfKiller(std::vector<CMove> lMoves) {
		int j=0;
		CMove temp;
		for(int i=0;i<lMoves.size();i++) {
			if(isitKiller(lMoves[i])) {
				temp = lMoves[i];
				lMoves[i] = lMoves[j];
				lMoves[j] = temp;
			}
		}
	}

float CPlayer::maxMoveT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue, CMove &tMove ) throw (int) {

      if (depth==0) {return pBoard.evaluate();}
      std::vector<CMove> lMoves;
      pBoard.FindPossibleMoves(lMoves,CELL_OWN);
      int j=0;
      for(int i=0;i<lMoves.size();i++) {
              if((pDue.Get()-CTime::GetCurrent().Get())/1000000.00<CRITICAL) { //std::cout<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00;
              throw -1;}      
              float temp = minValT(CBoard(pBoard,lMoves[i]),alph,beta,depth-1, pDue); //!!!! do i update alph???
              if(temp>alph) {
                            alph = temp;
                            j=i;
                            }
              if(alph>beta) {
                            tMove = lMoves[i];
                            return beta;
                            }
              }
      tMove = lMoves[j];
      return alph;
}

bool CPlayer::Idle(const CBoard &pBoard)
{
    if(depthChecked<0||depthChecked>50) return false;
    std::cout<<(CTime::GetCurrent().Get()-startTime.Get())/1000000.00<<" ";
    std::vector<CMove> lMoves;
    pBoard.FindPossibleMoves(lMoves,CELL_OTHER);
    if(lMoves.size()==0) return false;
    CMove tMove;
    CMove bMove;
    try {
    depthChecked+=1;
    int min = 999;
    int j=0;
    for(int i=0;i<lMoves.size();i++) {
            int temp = maxMoveT(CBoard(pBoard,lMoves[i]),-999,+999,depthChecked,idleReturnTime,tMove);
            //std::cout<<"min: "<<temp<<"\n";
            if(temp<=min) {
                         min=temp;
                         j=i;
                         bMove=tMove;
                         }
            }
    myNextBoard = CBoard(pBoard,lMoves[j]);
    myNextMove = bMove;
//    std::cout<<"tt:"<<(idleReturnTime.Get()-CTime::GetCurrent().Get())/1000000.00<<"\td: "<<depthChecked<<"\n";
	
    std::cout<<depthChecked<<" "<<(CTime::GetCurrent().Get()-startTime.Get())/1000000.00<<"\n";
    return true;
    } catch (int e) {
//            std::cout<<" oops! "<<CTime::GetCurrent().Get()/1000000<<"\n";
	    depthChecked--;
	std::cout<<depthChecked<<" "<<(CTime::GetCurrent().Get()-startTime.Get())/1000000.00<<"\n ";
            return false;
            }
}

void CPlayer::Initialize(bool pFirst,const CTime &pDue)
{
    //std::cout<<"time?"<<CTime::GetCurrent().Get()<<"\n due?"<<(pDue.Get())<<"\n";
    //std::cout<<"left?"<<CTime::GetCurrent().Get()-(pDue.Get())<<"\n";
    //int i; std::cin>>i;
	startTime = CTime::GetCurrent();
    srand(CTime::GetCurrent().Get());
//    guessBoard = 0;
    depthChecked = -1;
//    nextMove = 0;
}
    
float CPlayer::maxVal(const CBoard &pBoard,float alph,float beta,int depth ) {
//      std::cout<<"max "<<depth<<"\n";
//getch();//      bool a; std::cin>>a;
      if (depth==0) {/*std::cout<<pBoard.evaluate()<<"\n";*/return pBoard.evaluate();}
      std::vector<CMove> lMoves;
      pBoard.FindPossibleMoves(lMoves,CELL_OWN);
      for(int i=0;i<lMoves.size();i++) {
              float temp = minVal(CBoard(pBoard,lMoves[i]),alph,beta,depth-1); //!!!! do i update alph???
              if(temp>alph) alph = temp;
              if(alph>beta) return beta;
              }
      return alph;
}
    
float CPlayer::minVal(const CBoard &pBoard,float alph,float beta,int depth ) {
//      std::cout<<"min "<<depth<<"\n";
//      getch();
//      bool a; std::cin>>a;
      if (depth==0) return pBoard.evaluate();
      std::vector<CMove> lMoves;
      pBoard.FindPossibleMoves(lMoves,CELL_OTHER);
      for(int i=0;i<lMoves.size();i++) {
              float temp = maxVal(CBoard(pBoard,lMoves[i]),alph,beta,depth-1); //!!!! do i update alph???
              if(temp<beta) beta = temp;
              if(beta<alph) return alph;
              }
      return beta;
      
}
    
float CPlayer::maxValT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue ) throw (int) {
//      std::cout<<"max "<<depth<<"\n";
//getch();//      bool a; std::cin>>a;
      if (depth==0) {/*std::cout<<pBoard.evaluate()<<"\n";*/return pBoard.evaluate();}
      std::vector<CMove> lMoves;
//sortIfKiller(lMoves);
//
      pBoard.FindPossibleMoves(lMoves,CELL_OWN);
	int j=0;
      for(int i=0;i<lMoves.size();i++) {
              if((pDue.Get()-CTime::GetCurrent().Get())/1000000.00<CRITICAL) { //std::cout<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00;
              throw -1;}      
              float temp = minValT(CBoard(pBoard,lMoves[i]),alph,beta,depth-1, pDue); //!!!! do i update alph???
              if(temp>alph) {alph = temp; j=i;}
              if(alph>beta) {/*anotherKillerMove(lMoves[j]);*/return beta;}
              }
//      anotherKillerMove(lMoves[j]);
      return alph;
}
    
float CPlayer::minValT(const CBoard &pBoard,float alph,float beta,int depth,const CTime &pDue ) throw (int) {
//      std::cout<<"min "<<depth<<"\n";
//      getch();
//      bool a; std::cin>>a;
      if (depth==0) return pBoard.evaluate();
      std::vector<CMove> lMoves;
      pBoard.FindPossibleMoves(lMoves,CELL_OTHER);
      for(int i=0;i<lMoves.size();i++) {
              if((pDue.Get()-CTime::GetCurrent().Get())/1000000.00<CRITICAL) { //std::cout<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00;
              throw -1;}      
              float temp = maxValT(CBoard(pBoard,lMoves[i]),alph,beta,depth-1, pDue); //!!!! do i update alph???
              if(temp<beta) beta = temp;
              if(beta<alph) return alph;
              }
      return beta;
      
}

CMove CPlayer::Play(const CBoard &pBoard,const CTime &pDue)
{
std::cout<<"\nP:"<<(CTime::GetCurrent().Get()-startTime.Get())/1000000.00<<"\t";
    //Use the commented version if your system supports ANSI color (linux does)

    //pBoard.Print();
    //pBoard.PrintNoColor();

    std::vector<CMove> lMoves;
	
    pBoard.FindPossibleMoves(lMoves,CELL_OWN);

	CMove rMove;
	CTime sTime;
	CTime eTime;
	int depth=1;
	
/*	
do{
    std::cout<<"depth: "<<depth<<"\n";
    //sTime = CTime::GetCurrent();
    float max=-999;
	int j=0;
    for(int i=0;i<lMoves.size();i++) {
            float temp = minVal(CBoard(pBoard,lMoves[i]),-999,+999,depth);
            //std::cout<<"min: "<<temp<<"\n";
            if(temp>=max) {
                         max=temp;
                         j=i;
                         }
            }
    rMove = lMoves[j];
    eTime = CTime::GetCurrent();
    depth+=1;
    std::cout<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00<<"\n";
    if(depth>6) break;
} while (6*eTime.Get()-5*sTime.Get()<pDue.Get());
*/
if(depthChecked>0) {
                   if(myNextBoard.isSameAs(pBoard))
                   {
                       //std::cout<<"yay!\n";
                       rMove = myNextMove;
                       depth = depthChecked;
                   }
                   //else std::cout<<"nay!\n";
                   
                   }
do{
        //std::cout<<"d: "<<depth;
        try {
        float max=-999;
        int j=0;
        for(int i=0;i<lMoves.size();i++) {
            float temp = minValT(CBoard(pBoard,lMoves[i]),-999,+999,depth,pDue);
            //std::cout<<"min: "<<temp<<"\n";
            if(temp>=max) {
                         max=temp;
                         j=i;
                         }
            }
        rMove = lMoves[j];
        eTime = CTime::GetCurrent();
        depth+=1;
        } catch (int e) {
          break;
        }
        //std::cout<<"\tt:"<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00<<"\n";
        if(depth>50) break;
} while(true);
	
//epic
      //std::cout<<"\n";
    //CBoard(pBoard,rMove).Print();
	depthChecked = 0;
	idleReturnTime = CTime(CTime::GetCurrent().Get()+8000000);
	std::cout<<"\t"<<(pDue.Get()-CTime::GetCurrent().Get())/1000000.00<<"\t";
	



    /*
     * Here you should write your clever algorithms to get the best next move.
     * This skeleton returns a random movement instead.
     */
std::cout<<"p:"<<(CTime::GetCurrent().Get()-startTime.Get())/1000000.00<<"\n";
    return rMove;
}

/*namespace chk*/ }
